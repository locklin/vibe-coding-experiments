library(testthat)
library(mlpack)

test_check("mlpack")
