#ifndef B_HPP
#define B_HPP

namespace B {

void B();

}

#endif
